<div class="news-letter-form">

    <div class="news-letter-form-container">



    <h1>Sign up for newsletter</h1>
    <p>
        If you want relevant updates occasionally, sign up for the private newsletter. Your email is never shared.
    </p>

    <form action="">

        <div class="email-input">
            <input type="email" name="email" placeholder="Enter Your Email..." id="">

            <button type="submit">SIGN UP</button>
        </div>

    </form>
    
</div>


</div>