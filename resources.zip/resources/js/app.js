require('./bootstrap');

import Menu from './Menu'

class Main{

    
    
    constructor(){
      this.menuClass = new Menu()
    }



}

//Initialize

let obj = new Main();